-- Migración para mejorar el agente IA de WhatsApp + Gemini.
-- Ejecutar antes de desplegar los .java modificados.

-- 1) Configuración de productos para IA
ALTER TABLE ai_products_config
    ADD COLUMN IF NOT EXISTS intent VARCHAR(50),
    ADD COLUMN IF NOT EXISTS priority INTEGER DEFAULT 100,
    ADD COLUMN IF NOT EXISTS media_id_whatsapp VARCHAR(255),
    ADD COLUMN IF NOT EXISTS image_caption TEXT;

UPDATE ai_products_config
SET priority = COALESCE(priority, 100)
WHERE priority IS NULL;

-- 2) Base de conocimiento / FAQs
ALTER TABLE ai_knowledge_base
    ADD COLUMN IF NOT EXISTS intent VARCHAR(50),
    ADD COLUMN IF NOT EXISTS active BOOLEAN DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS priority INTEGER DEFAULT 100,
    ADD COLUMN IF NOT EXISTS media_id_whatsapp VARCHAR(255),
    ADD COLUMN IF NOT EXISTS media_caption TEXT;

UPDATE ai_knowledge_base
SET active = COALESCE(active, TRUE),
    priority = COALESCE(priority, 100)
WHERE active IS NULL OR priority IS NULL;

-- 3) Zonas de envío: aliases para detectar abreviaturas como SJL, VMT, etc.
ALTER TABLE shipping_coverage
    ADD COLUMN IF NOT EXISTS aliases TEXT;

-- 4) Evita duplicidad real de webhooks de Meta por wamid.
CREATE UNIQUE INDEX IF NOT EXISTS uq_whatsapp_messages_wamid
ON whatsapp_messages(wamid)
WHERE wamid IS NOT NULL;

-- 5) Tabla opcional para estado conversacional. El código actual no la exige todavía,
-- pero queda preparada para la siguiente fase: creación de pedidos paso a paso.
CREATE TABLE IF NOT EXISTS ai_conversation_state (
    phone VARCHAR(30) PRIMARY KEY,
    current_state VARCHAR(80),
    last_intent VARCHAR(80),
    selected_product_code VARCHAR(80),
    quantity INTEGER,
    district VARCHAR(120),
    address TEXT,
    reference TEXT,
    payment_method VARCHAR(80),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- 6) Settings recomendados si tu tabla de settings usa key/value.
-- Ajusta nombres de columnas si tu tabla de configuración usa otra estructura.
-- app.public.base.url debe ser una URL pública HTTPS, no localhost, para imágenes por link.
-- whatsapp.api.version permite cambiar versión de Graph API sin recompilar.
