# Cambios aplicados al chatbot WhatsApp + Gemini

## Archivos modificados

- `service/GeminiService.java`
- `controller/WhatsAppWebhookController.java`
- `service/WhatsAppApiService.java`
- `dao/AiConfigDaoImpl.java`
- `model/AiProductConfig.java`
- `model/AiKnowledgeBase.java`
- `model/ShippingCoverage.java`

## Cambios funcionales

1. Gemini ahora trabaja como motor de decisión estructurada en JSON, no como texto libre con etiquetas `[IMG]`.
2. El backend interpreta el JSON y decide si envía texto, imagen, caption o deriva a humano.
3. Se agregó envío de imagen con `caption` mediante `sendMediaMessage(..., caption)`.
4. Se mantiene compatibilidad con llamadas antiguas de `sendMediaMessage` sin caption.
5. Se mejoró la detección de productos por palabras clave, código, nombre, intención y términos como promo, pack, oferta, bidón, recarga.
6. Se agregó soporte para responder audios con Gemini. El webhook ya permite flujo IA para `text` y `audio`.
7. Se mejoró la detección de derivación humana: asesor, humano, persona, reclamo, queja, no me entiendes, etc.
8. Se dejó de loguear parcialmente la API Key de Gemini.
9. La versión de WhatsApp Graph API ahora puede leerse desde `whatsapp.api.version`; por defecto usa `v18.0`.
10. Los productos sin configuración explícita en `ai_products_config` quedan desactivados para IA por defecto: `COALESCE(a.ai_enabled, FALSE)`.

## Migración requerida

Ejecutar antes de desplegar:

```sql
sql/20260626_ai_chatbot_improvements.sql
```

Si no ejecutas la migración, el backend fallará al leer columnas nuevas como:

- `intent`
- `priority`
- `media_id_whatsapp`
- `image_caption`
- `media_caption`
- `aliases`

## Configuración recomendada

Agregar en settings:

```text
app.public.base.url=https://tudominio.com
whatsapp.api.version=v18.0
```

`app.public.base.url` debe ser público si usas imágenes por URL. Para producción es más estable usar `media_id_whatsapp`.

## Formato JSON esperado desde Gemini

```json
{
  "intent": "promocion",
  "reply_text": "Tenemos una promoción especial para familias que consumen agua frecuentemente.",
  "send_media": true,
  "media_type": "image",
  "media_id": "1234567890",
  "image_url": null,
  "caption": "Promo ANTARQUI 💧 Pack familiar por S/ 48.00",
  "buttons": ["Quiero pedir", "Consultar delivery"],
  "next_state": "esperando_confirmacion_pedido",
  "needs_human": false
}
```

## Nota de despliegue

Este ZIP contiene solo la carpeta de código que enviaste. No incluye `pom.xml`, `application.properties`, Dockerfile ni esquema completo del proyecto, por lo que no se compiló con Maven dentro del entorno. La revisión fue estática y los cambios fueron armados respetando las firmas actuales para reducir riesgo de ruptura.
